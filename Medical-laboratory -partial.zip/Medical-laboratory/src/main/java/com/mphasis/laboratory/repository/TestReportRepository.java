package com.mphasis.laboratory.repository;

public interface TestReportRepository {

}
