package com.mphasis.laboratory.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mphasis.laboratory.entity.Appointment;
import com.mphasis.laboratory.service.AppointmentService;
@RestController
@RequestMapping("/appointment")
public class AppointmentController {

		@Autowired 
		AppointmentService appointmentService;
		@GetMapping("/")
		public List<Appointment> retrieveAllAppointments()
		{
			List<Appointment>appointments= appointmentService.read();
			return appointments;
		}
		@GetMapping("/{appointmentId}")
		public Appointment findAppointmentById(@PathVariable("appointmentId") String appointmentId)
		{
			return appointmentService.read(appointmentId);
		}
		@PostMapping("/")
		public Appointment addAppointment(@RequestBody Appointment appointment)
		{
			return appointmentService.create(appointment);
		}
		@PutMapping("/")
		public Appointment modifyAppointment(@RequestBody Appointment appointment)
		{
			return appointmentService.update(appointment);
		}
		@DeleteMapping("/{appointmentId}")
		public void deleteAppointment(@PathVariable("appointmentId") String appointmentId)
		{
			appointmentService.delete(appointmentId);
		}
	
	
	
	
	
	

}
