package com.mphasis.laboratory.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="Patient")
public class Patient {
	@Id
	private String patientId;
	private String patientFirstname;
	private String patientLastName;
	private String age;
	private String gender;
	private String phoneNumber;
	private String email;
	private String password;
	 @OneToMany(fetch = FetchType.LAZY,
	            cascade =  CascadeType.ALL,
	            mappedBy = "patient")
	 private List<Appointment> appointmentList;
 //	    private Appointment appointment;
	public Patient() {}
	public String getPatientId() {
		return patientId;
	}
	public void setPatientId(String patientId) {
		this.patientId = patientId;
	}

	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getPatientFirstname() {
		return patientFirstname;
	}
	public void setPatientFirstname(String patientFirstname) {
		this.patientFirstname = patientFirstname;
	}
	public String getPatientLastName() {
		return patientLastName;
	}
	public void setPatientLastName(String patientLastName) {
		this.patientLastName = patientLastName;
	}
	public Patient(String patientId, String patientFirstname, String patientLastName, String age, String gender,
			String phoneNumber, String email, String password) {
		super();
		this.patientId = patientId;
		this.patientFirstname = patientFirstname;
		this.patientLastName = patientLastName;
		this.age = age;
		this.gender = gender;
		this.phoneNumber = phoneNumber;
		this.email = email;
		this.password = password;
	}
	@Override
	public String toString() {
		return "Patient [patientId=" + patientId + ", patientFirstname=" + patientFirstname + ", patientLastName="
				+ patientLastName + ", age=" + age + ", gender=" + gender + ", phoneNumber=" + phoneNumber + ", email="
				+ email + ", password=" + password + "]";
	}
	
}