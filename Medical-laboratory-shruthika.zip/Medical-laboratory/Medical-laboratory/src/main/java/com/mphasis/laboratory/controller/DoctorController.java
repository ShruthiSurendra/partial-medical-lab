package com.mphasis.laboratory.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mphasis.laboratory.entity.Doctor;
import com.mphasis.laboratory.entity.Patient;
import com.mphasis.laboratory.service.DoctorService;

@RestController
@RequestMapping("/doctor")
public class DoctorController {
	@Autowired 
	DoctorService doctorService;
	@GetMapping("/")
	public List<Doctor> retrieveAllDoctors()
	{
		List<Doctor>doctors= doctorService.read();
		return doctors;
	}
	@GetMapping("/{doctorId}")
	public Doctor findDoctorById(@PathVariable("doctorId") String doctorId)
	{
		return doctorService.read(doctorId);
	}
	@PostMapping("/")
	public Doctor AddDoctor(@RequestBody Doctor doctor)
	{
		return doctorService.create(doctor);
	}
	@PutMapping("/")
	public Doctor modifyDoctor(@RequestBody Doctor doctor)
	{
		return doctorService.update(doctor);
	}
	@DeleteMapping("/{doctorId}")
	public void deleteDoctor(@PathVariable("doctorId") String doctorId)
	{
		doctorService.delete(doctorId);
	}
}
