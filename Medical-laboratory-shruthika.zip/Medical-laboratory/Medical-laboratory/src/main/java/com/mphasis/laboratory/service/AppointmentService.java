package com.mphasis.laboratory.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.mphasis.laboratory.entity.Appointment;
import com.mphasis.laboratory.repository.AppointmentRepository;


@Component("as")
public class AppointmentService {
	@Autowired
	AppointmentRepository appointmentRepo;
	public Appointment create(Appointment appointment)
	{
		return appointmentRepo.save(appointment);
	}
	public List<Appointment> read()
	{
		return appointmentRepo.findAll();
	}
	public Appointment read(String appointmentId)
	{
		return appointmentRepo.findById(appointmentId).get();
	}
	public Appointment update(Appointment appointment)
	{
		return appointmentRepo.save(appointment);
	}
	public void delete(String appointmentId)
	{
		appointmentRepo.delete(read(appointmentId));
	}
	
	

}
